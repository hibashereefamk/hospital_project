from django.shortcuts import redirect,render
from django.contrib.auth import login,logout
from django.contrib.auth.forms import UserCreationForm,AuthenticationForm


def register_view(request):
    if request.user.is_authenticated:
        return redirect('index')

    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()  # create user
            login(request, user)  # auto login
            return redirect('index')  # MUST RETURN
        else:
            return render(request, "register.html", {"form": form})  # RETURN ON INVALID FORM

    # GET request
    form = UserCreationForm()
    return render(request, "register.html", {"form": form})

def login_view(request):
    if request.user.is_authenticated:
        return redirect('index')
    if request.method == 'POST':
        form=AuthenticationForm(request,data=request.POST)
        if form.is_valid():
            user=form.get_user()
            login(request,user)
            return redirect('index')
    else:
        form=AuthenticationForm()
        return render(request,'login.html',{'form':form})
    
def logout_view(request):
    if request.method == 'POST':
        logout(request)
        return redirect('index')

